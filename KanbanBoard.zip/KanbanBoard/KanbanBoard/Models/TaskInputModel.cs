﻿namespace KanbanBoard.Models
{
    public class TaskInputModel
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}

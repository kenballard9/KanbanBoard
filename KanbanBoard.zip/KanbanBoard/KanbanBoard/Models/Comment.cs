﻿using System;

namespace KanbanBoard.Models
{
    public class Comment
    {
        public string Content { get; set; } // Rich text HTML allowed
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}

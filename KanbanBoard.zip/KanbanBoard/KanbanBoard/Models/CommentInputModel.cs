﻿using System;

namespace KanbanBoard.Models
{
    public class CommentInputModel
    {
        public Guid TaskId { get; set; }
        public string Content { get; set; }
    }
}
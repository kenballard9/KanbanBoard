﻿namespace KanbanBoard.Models
{
    public enum StatusOfTask
    {
        ToDo,
        InProgress,
        Done
    }

    public class KanbanTask
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public StatusOfTask Status { get; set; } = StatusOfTask.ToDo;
    }
}

using Microsoft.AspNetCore.Mvc;
using KanbanBoard.Models;

namespace KanbanBoard.Controllers
{
    public class HomeController : Controller
    {
        // Temporary in-memory task list
        private static List<KanbanTask> tasks = new();
        private static int nextId = 1;

        public IActionResult Index()
        {
            return View(tasks);
        }

        [HttpPost]
        public IActionResult AddTask(string title, string description)
        {
            tasks.Add(new KanbanTask
            {
                Id = nextId++,
                Title = title,
                Description = description,
                Status = StatusOfTask.ToDo
            });
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult MoveTask(int id, StatusOfTask newStatus)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                task.Status = newStatus;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult DeleteTask(int id)
        {
            tasks.RemoveAll(t => t.Id == id);
            return RedirectToAction("Index");
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using KanbanBoard.Models;

namespace KanbanBoard.Controllers
{
    public class HomeController : Controller
    {
        private static List<KanbanTask> tasks = new List<KanbanTask>();

        public IActionResult Index()
        {
            return View(tasks);
        }

        [HttpPost]
        public IActionResult AddTask([FromBody] TaskInputModel input)
        {
            if (string.IsNullOrWhiteSpace(input.Title))
                return BadRequest();

            var newTask = new KanbanTask
            {
                Id = Guid.NewGuid(),
                Title = input.Title,
                Description = input.Description,
                Status = StatusOfTask.ToDo,
                Comments = new List<Comment>()
            };

            tasks.Add(newTask);
            return Ok();
        }

        // ✅ JSON-based MoveTask
        [HttpPost]
        public IActionResult MoveTask([FromBody] MoveTaskInput input)
        {
            var task = tasks.FirstOrDefault(t => t.Id == Guid.Parse(input.id));
            if (task != null)
            {
                task.Status = Enum.Parse<StatusOfTask>(input.newStatus);
            }
            return Ok();
        }

        [HttpPost]
        public IActionResult AddComment([FromBody] AddCommentInput input)
        {
            var task = tasks.FirstOrDefault(t => t.Id == Guid.Parse(input.TaskId));
            if (task != null && !string.IsNullOrWhiteSpace(input.Content))
            {
                if (task.Comments == null)
                    task.Comments = new List<Comment>();

                task.Comments.Add(new Comment { Content = input.Content });
            }
            return Ok();
        }

        // Input models for JSON binding
        public class TaskInputModel { public string Title { get; set; } public string Description { get; set; } }
        public class MoveTaskInput { public string id { get; set; } public string newStatus { get; set; } }
        public class AddCommentInput { public string TaskId { get; set; } public string Content { get; set; } }
    }
}
